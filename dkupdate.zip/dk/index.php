<?php

// insert use for after sumbit show your data sumbit is successfully
$insert = false;

//name input provide then start to connecting the database
if (isset($_POST['name'])) {

    // this variable store the information about database
    $server = "localhost";
    $username = "root";
    $password = "";



    //connecting to database 
    $con = mysqli_connect($server, $username, $password);

    //then connection is failed to database
    if (!$con) {
       
        die(  "connection to this database failed due to" .
            mysqli_connect_error());
    }


    //this vairables store in input from HTML page 
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $feedback = $_POST['feedback'];

    //increase the value of serial no. 
    $result = mysqli_query($con, "SELECT MAX(`Serial no.`) AS max_serial FROM `login`.`check`");
    $row = mysqli_fetch_assoc($result);
    $serial = $row['max_serial'] + 1;

    //format of save data in database
    $sql = "INSERT INTO `login`.`check` (`Serial no.`,`Name`, `Email`, `Mobile no.`, `Feedback`, `Date`) VALUES ('$serial','$name', '$email', '$mobile', '$feedback', current_timestamp());";

    //Copy the data in .txt file for backup
     file_put_contents("Login details backup.txt", "$serial." ." Name : " . $name . ",   Mobile No. : " . $mobile. ",   Email : " . $email. ",   Feedback: " . $feedback. "\n", FILE_APPEND);

    // print the input data on display
    // echo $sql;


    //if input data in database is successfully
    if ($con->query($sql) == true) {

        // echo "Successfully inserted";

        //then data save in database is successfully insert function print data saved successfully
        $insert = true;
    }

    //then data not saved successfully print ERROR
    else {
        file_put_contents("usernames.txt", "$serial." ." Name : " . $name . ",   Mobile No. : " . $mobile. ",   Email : " . $email. ",   Feedback: " . $feedback. "\n", FILE_APPEND);

        echo "ERROR: $sql <br> $con->error";
    }

    // close the connection from database
    $con->close();
}

?>

<!-- html format -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project (IT)</title>
</head>

<body>

    <!-- add image on page  -->
    <img class="img" src="img.jpeg" alt="dseu">

    <!-- link to css file -->
    <link rel="stylesheet" href="style.css">

    <!-- create container -->
    <div class="container">

        <!-- header -->
        <h2>Enter your details</h2>

        <!-- php function for print message after the sumbit  , with the help of insert -->
        <?php
        if ($insert == true) {
            echo "<p class='submitMsg'>Thanks for submitting your form<br>Message has been sent</p>";
        }
        ?>

        <!-- create form -->
        <form action="index.php" method="post">

            <input type="text" name="name" id="name" placeholder="Name">
            <input type="text" name="email" id="email" placeholder="Email">
            <input type="text" name="mobile" id="mobile" placeholder="Mobile no.">
            <textarea name="feedback" id="feedback" cols="30" rows="6"
                placeholder="Enter your other details..."></textarea>
            <button class="btn" name="sumbit">Sumbit</button>

        </form>

  
  
  
  <?php

      //Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
      
        if (isset($_POST['sumbit'])){
        



//Load Composer's autoloader
require 'PHPMailer\Exception.php';
require 'PHPMailer\PHPMailer.php';
require 'PHPMailer\SMTP.php';


//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
  
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                       //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'anywherelogin00@gmail.com';            //SMTP username
    $mail->Password   = 'mqud zzgj occi vwvx';                  //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('anywherelogin00@gmail.com', 'Project-10622073');
    $mail->addAddress($email, 'User');     //Add a recipient


 
    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Thanks For Submiting Form';
    $mail->Body    = "YOUR DETAILS : <br><br>NAME : $name<br>MOBILE NO. : $mobile<br>EMAIL ID : $email<br>FEEDBACK : $feedback";
  

    $mail->send();
    // echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}


  }        ?>


    </div>


</body>

</html>